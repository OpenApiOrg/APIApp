package com.tcs.opi.app.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tcs.opi.app.domain.RestTestVO;

@RestController
public class RestConsumeController {
	
   
    @RequestMapping("/api/test")
    String getRestConsumeTest() {

    	System.out.println("Inside /api/test....");
    	
    	Gson gson = new GsonBuilder().create();
    	
    	RestTemplate restTemplate = new RestTemplate();
    	
    	String aa = restTemplate.getForObject("http://gturnquist-quoters.cfapps.io/api/random", String.class);
       // System.out.println(""+restVO.toString());
     
    	
    	/*RestTemplate restTemplate = new RestTemplate();
    	RestTestVO restVO = restTemplate.getForObject("http://gturnquist-quoters.cfapps.io/api/random", RestTestVO.class);
       System.out.println(""+restVO.toString());
    System.out.println("rest sample type:::"+ restVO.getType());
    	return restVO.getType();*/
    	RestTestVO restVO = gson.fromJson(aa, RestTestVO.class);
    	
    	
    	return restVO.getType();
    	
    }
	
}
