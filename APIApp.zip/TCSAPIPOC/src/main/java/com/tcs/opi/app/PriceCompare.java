package com.tcs.opi.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Iterator;

import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.basic.DefaultOAuthConsumer;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.basic.DefaultOAuthConsumer;

//import oauth.signpost.signature.SignatureMethod;
 
public class PriceCompare {
 
  private static String readAll(Reader rd) throws IOException {
    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = rd.read()) != -1) {
      sb.append((char) cp);
    }
    return sb.toString();
  }
 
  public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException, OAuthMessageSignerException, OAuthExpectationFailedException, OAuthCommunicationException {

	  OAuthConsumer consumer = new DefaultOAuthConsumer("SEM3735D7BCE38CA7A9E9513951153E2E4E2", "MGJjOTlmNWJiMGMwNWMxMmJhNTY3MmQ2MDgxOWY3ODQ");
	       consumer.setTokenWithSecret("", "");
	  
	  
	  URL url1 = new URL(url);
	  HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
	  System.out.println("url is " + url);
	  conn.setRequestMethod("GET"); 
	  conn.setRequestProperty("User-Agent", "Semantics3 Java Library");
	  consumer.sign(conn);
	  conn.connect();
	  InputStream is = conn.getInputStream();

	  try {
      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
      String jsonText = readAll(rd);
      JSONObject json = new JSONObject(jsonText);
      return json;
    } finally {
      is.close();
    } 
  }
 
  public void priceCompare(String datasearch1) throws IOException, JSONException, OAuthMessageSignerException, OAuthExpectationFailedException, OAuthCommunicationException {
	 
	  try
	  {
		String url = "jdbc:mysql://localhost:3306/"; 
		String dbName = "test"; 
		String driver = "com.mysql.jdbc.Driver"; 
		String userName = "root"; 
		String password = "tcspoc"; 
			Class.forName(driver).newInstance(); 
			Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
			Statement st = null; 
	  
	 
       System.out.println("https://api.semantics3.com/test/v1/products?q={\"search\":\"xbox one\"}");
       
		String req = new StringBuffer()
				.append("https://api.semantics3.com/test/v1/")
				.append("products")
				.append("?q=")
				.append(URLEncoder.encode("{\"search\":\"" + datasearch1 + "\"}", "UTF-8"))
				.toString();
       JSONObject results = readJsonFromUrl(req);
       
       JSONArray array = results.getJSONArray("results");
		System.out.println("category,name,url,price,seller,visactive");
		Statement st1 = conn.createStatement();
		st1.executeUpdate("delete from price where data_search='" + datasearch1 + "'");
		st1.close();
		for (int i = 0; i < array.length(); i++) {
		    JSONObject row = array.getJSONObject(i);
		    String vcategory=row.getString("category").replace("'", "");
		    String vname=row.getString("name").replace("'", "");
		    JSONArray arrsub1 = row.getJSONArray("sitedetails");
		    for (int j = 0; j < arrsub1.length(); j++) {
		    	JSONObject rowsub1 = arrsub1.getJSONObject(j);
		    	String vurl=rowsub1.getString("url").replace("'", "");
		    	//String vname=rowsub1.getString("name");
			    JSONArray arrsub2 = rowsub1.getJSONArray("latestoffers");
			    for (int k = 0; k < arrsub2.length(); k++) {
			    	JSONObject rowsub2 = arrsub2.getJSONObject(k);
			    	String vprice=rowsub2.getString("price");
			    	String vseller=rowsub2.getString("seller").replace("'", "");
			    	int visactive=rowsub2.getInt("isactive");
			    	//System.out.println("INSERT into price_compare VALUES('" + vcategory + "','" + vname + "','" + vurl + "'," + vseller  + ",'" + vprice + "'," + visactive + ")");
			    
			    	st = conn.createStatement();
					
			    	int val = st.executeUpdate("INSERT into price (category,data_search,url,seller,price,active,name) VALUES ('" + vcategory + "','" + vname + "','" + vurl + "','" + vseller  + "','" + vprice + "','" + visactive + "','"+ datasearch1 +"')");
					if(val==1) System.out.print("Successfully inserted value"); 
					st.close(); 
			    
			    
			    }    
		    }    
		}
		
		conn.close();

    
	  }
	  catch (Exception e)
	  {
		  e.printStackTrace();
	  }
    
  }
}