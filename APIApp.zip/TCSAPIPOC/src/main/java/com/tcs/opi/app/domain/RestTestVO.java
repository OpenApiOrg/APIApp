package com.tcs.opi.app.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown=true)
public class RestTestVO {

	

	private String type;
	
	private ValueVO value;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ValueVO getValue() {
		return value;
	}

	public void setValue(ValueVO value) {
		this.value = value;
	}



	


}