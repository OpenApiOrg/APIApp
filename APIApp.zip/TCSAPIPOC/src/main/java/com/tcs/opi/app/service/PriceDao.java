package com.tcs.opi.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tcs.opi.app.domain.Price;

@Repository
@Transactional
public class PriceDao {
  
  @Autowired
  private SessionFactory _sessionFactory;
  
  private Session getSession() {
    return _sessionFactory.getCurrentSession();
  }

  public void save(Price price) {
    getSession().save(price);
    return;
  }
  
  public void delete(Price price) {
    getSession().delete(price);
    return;
  }
  
  @SuppressWarnings("unchecked")
  public List<Price> getAll() {
    return getSession().createQuery("from Price").list();
  }
  
  public List<Price> getByName(String name) {
	  System.out.println("in dao" + name);
	  List<Price> list1=null;
    return (List<Price>) getSession().createQuery(
        "from Price where name = :name")
        .setParameter("name", name)
        .list();
  }

  public Price getById(long id) {
    return (Price) getSession().load(Price.class, id);
  }

  public void update(Price price) {
    getSession().update(price);
    return;
  }

} // class UserDao
