package com.tcs.opi.app.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown=true)
public class ValueVO {

	

	private String id;
	
	private String quotess;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/*public String getQuote() {
		return quote;
	}

	public void setQuote(String quote) {
		this.quote = quote;
	}*/

	
	
	
	

}