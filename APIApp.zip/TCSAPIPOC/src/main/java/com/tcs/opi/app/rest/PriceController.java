package com.tcs.opi.app.rest;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.opi.app.PriceCompare;
import com.tcs.opi.app.domain.Price;
import com.tcs.opi.app.service.PriceDao;


@RestController
@RequestMapping(value="/price")
public class PriceController {

  @Autowired
  private PriceDao _priceDao;
  
  @RequestMapping(value="/delete")
  @ResponseBody
  public String delete(long id) {
    try {
      Price price = new Price(id);
      _priceDao.delete(price);
    }
    catch(Exception ex) {
      return ex.getMessage();
    }
    return "Price succesfully deleted!";
  }
  
  @RequestMapping(value="/get-by-name")
  @ResponseBody
  public List<Price> getByEmail(String name) {
    String priceId;
    List<Price> priceList = null;
    try {
    	PriceCompare pc=new PriceCompare();
    	pc.priceCompare(name);
    	System.out.println("price compare done for " + name);
    	
    priceList = _priceDao.getByName(name);
      //priceId = String.valueOf(user.getId());
    
    }
    catch(Exception ex) {
      ex.printStackTrace();
    	//return "User not found";
      
    }
    //return "The price id is: "; // + priceId;
    return priceList;
  }

  @RequestMapping(value="/save")
  @ResponseBody
  public String create(String category, String name, String url, String seller, String price, String active, String data_search) {
    try {
      Price priceObj = new Price(category, name, url, seller, price, active, data_search);
      _priceDao.save(priceObj);
    }
    catch(Exception ex) {
      return ex.getMessage();
    }
    return "User succesfully saved!";
  }
  
  @RequestMapping(value="/PriceList")
  @ResponseBody
  public List<Price> getAllPrice() {
  //public String getAllPrice() {
	  String temp = "";
	//  return "User called";
	  
	  Price price1 = new Price();
	  
	  List<Price> priceList = null;
	  
	  try {
     	  priceList = _priceDao.getAll();
    	
    	System.out.println("price list size::::"+priceList.size());
    	
    	
    }
    catch(Exception ex) {
      System.out.println(ex.getMessage());;
    }
    return priceList;
  }

} // class UserController