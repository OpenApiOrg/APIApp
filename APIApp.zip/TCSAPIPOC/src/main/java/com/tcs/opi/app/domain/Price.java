package com.tcs.opi.app.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="price")
public class Price {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long id;
  
  /*@NotNull*/
 /* @Size(min = 3, max = 80)*/
  private String category;
  
  /*@NotNull*/
 /* @Size(min = 2, max = 80)*/
  private String name;
  
  private String url;
  
  private String seller;
  
  private String price;
  
  private String active;
  
  private String data_search;
  

  public Price() { }

  public Price(long id) { 
    this.id = id;
  }

  public Price(String category, String name, String url, String seller, String price, String active, String data_search) {
    this.category = category;
    this.name = name;
    this.url = url;
    this.seller = seller;
    this.price = price;
    this.active = active;
    this.data_search = data_search;
    
  }

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}


public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public String getUrl() {
	return url;
}

public void setUrl(String url) {
	this.url = url;
}

public String getSeller() {
	return seller;
}

public void setSeller(String seller) {
	this.seller = seller;
}

public String getPrice() {
	return price;
}

public void setPrice(String price) {
	this.price = price;
}

public String getActive() {
	return active;
}

public void setActive(String active) {
	this.active = active;
}

public String getData_search() {
	return data_search;
}

public void setData_search(String data_search) {
	this.data_search = data_search;
}
  
} // class User