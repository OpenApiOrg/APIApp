package com.tcs.poc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
          sb.append((char) cp);
        }
        return sb.toString();
      }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String url="http://localhost:8090/price/get-by-name?name="+request.getParameter("searchstr");
		System.out.println(url);
		out.println("<HTML><CENTER>");
		out.println("<B><font size=5>Welcome to Price Compare Tool!</font></B>");
		out.println("<br>");
		
		URL url1 = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
		InputStream is = conn.getInputStream();
		System.out.println("after input strea");
		try {
		
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
		      String jsonText = readAll(rd);
		      System.out.println("wow here:" + jsonText);
		      jsonText.replace("\"", "");
		      System.out.println("wow here1:" + jsonText.length());
		      int lp=0;
		      int strvar=0;
		      String var1="";
		      out.println("<TABLE BORDER=1><TR>");
		      int jj=0;
		      int urln=4;
		      while(lp<jsonText.length())
		      {
		    	  
		    	  if(jsonText.charAt(lp)==',')
		    	  {
		    		  jj++;
		    		  out.print("<TD>");
		    		  if(jj==urln)
		    		  {
		    			  out.println("<A HREF="+ var1 +">");
		    			  urln=urln+8;
		    		  }
		    		  out.print(var1.replace('\"', ' '));
		    		  if(jj+8==urln)
		    			  out.println("</A>");
		    		  out.print("</TD>");
		    		  strvar=0;
		    		  
		    	  }
		    	  if(jsonText.charAt(lp)=='}')
		    	  {
		    		  jj++;
		    		  out.print("<TD>"+var1.replace('\"', ' ')+"</TD></TR><TR>");
		    		  strvar=0;
		    		  lp++;
		    	  }
		    	  if(strvar==1)
		    		  var1=var1+jsonText.charAt(lp);
		    	  else
		    		  var1="";
		    	  if(jsonText.charAt(lp)==':')
		    		  strvar=1;
		    	  lp++;
		      }
		      out.println("</TR></TABLE>");
		      
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	         
	     //out.println("<TR><TD>test</TD></TR>");
		 

		out.print("<B>Back to Square</B>:" + request.getParameter("searchstr"));
		response.getWriter().append("Served at: ").append(request.getContextPath());
		out.println("</HTML>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
